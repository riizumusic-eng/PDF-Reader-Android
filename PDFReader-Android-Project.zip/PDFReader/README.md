# PDF Reader — Android

Projeto Android nativo em Kotlin para abrir e ler PDFs localmente.

## Recursos implementados
- Seleção de PDF pelo seletor de documentos do Android (sem pedir acesso amplo ao armazenamento).
- Renderização de páginas com `PdfRenderer` do Android.
- Navegação página anterior/próxima e salvamento da última página.
- Pesquisa textual no documento usando PDFBox-Android (não faz OCR de páginas digitalizadas).
- Favoritos por documento e compartilhamento do PDF.
- Tema escuro/claro.

## Gerar APK no Android Studio
1. Instale Android Studio (versão recente) e JDK 17.
2. Abra a pasta `PDFReader` no Android Studio.
3. Aguarde a sincronização do Gradle e a instalação do Android SDK 35.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Observações
Este pacote contém o projeto-fonte. O ambiente em que ele foi preparado não possui Android SDK nem Gradle instalados, portanto o APK ainda precisa ser compilado no Android Studio. Antes de publicar, teste em diferentes aparelhos e adicione ícone, política de privacidade e assinatura de release.
