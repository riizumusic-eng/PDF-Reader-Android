# Gerar o APK usando somente o celular

Este projeto inclui uma compilação automática pelo GitHub Actions.

1. No Chrome do Android, entre em https://github.com e crie uma conta ou faça login.
2. Crie um repositório novo, por exemplo `PDFReader`.
3. Extraia este ZIP usando o app Arquivos do Android.
4. No repositório GitHub, use **Add file > Upload files** e envie todo o conteúdo de dentro da pasta `PDFReader` (incluindo a pasta oculta `.github`).
5. Faça o commit na branch `main`.
6. Abra a aba **Actions** do repositório. Se solicitado, habilite GitHub Actions.
7. Selecione **Build PDF Reader APK** e toque em **Run workflow** (o envio inicial para `main` também inicia a compilação).
8. Quando o processo terminar com marca verde, abra a execução e baixe o artefato **PDF-Reader-APK**.
9. Extraia o ZIP baixado. Toque em `app-debug.apk` e autorize a instalação pelo navegador/Arquivos se o Android solicitar.

A compilação é feita nos servidores do GitHub; o celular só precisa do navegador. O artefato é temporário e fica disponível por 14 dias.
