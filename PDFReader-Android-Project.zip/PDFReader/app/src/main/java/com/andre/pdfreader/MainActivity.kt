package com.andre.pdfreader

import android.app.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.*
import android.view.*
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.content.ContextCompat
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("reader", MODE_PRIVATE) }
    private var renderer: PdfRenderer? = null
    private var descriptor: android.os.ParcelFileDescriptor? = null
    private var currentUri: Uri? = null
    private var page = 0
    private var dark = true
    private lateinit var root: LinearLayout
    private lateinit var pageImage: ImageView
    private lateinit var pageLabel: TextView
    private lateinit var titleLabel: TextView
    private lateinit var emptyState: LinearLayout
    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> uri?.let { openPdf(it) } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PDFBoxResourceLoader.init(applicationContext)
        dark = prefs.getBoolean("dark", true)
        buildHome()
        currentUri = prefs.getString("last_uri", null)?.let(Uri::parse)
        page = prefs.getInt("last_page", 0)
        currentUri?.let { try { openPdf(it, false) } catch (_: Exception) { } }
    }

    private fun buildHome() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(22, 18, 22, 12); setBackgroundColor(bg()) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val brand = TextView(this).apply { text = "▣  PDF Reader"; textSize = 25f; setTextColor(fg()); typeface = Typeface.DEFAULT_BOLD }
        header.addView(brand, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(action("☾", "Alternar tema") { toggleTheme() })
        root.addView(header)
        val subtitle = TextView(this).apply { text = "Sua biblioteca, do seu jeito."; textSize = 14f; setTextColor(muted()); setPadding(2, 7, 0, 18) }
        root.addView(subtitle)
        val open = action("＋  Abrir PDF", "Selecionar documento") { picker.launch(arrayOf("application/pdf")) }
        open.setBackgroundColor(Color.rgb(37, 99, 235)); open.setTextColor(Color.WHITE); open.textSize = 16f
        root.addView(open, LinearLayout.LayoutParams(-1, 54).apply { bottomMargin = 14 })
        titleLabel = TextView(this).apply { text = "LEITURA ATUAL"; textSize = 11f; letterSpacing = 1.2f; setTextColor(muted()); setPadding(2, 8, 0, 8) }
        root.addView(titleLabel)
        emptyState = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(12, 38, 12, 38) }
        emptyState.addView(TextView(this).apply { text = "▤"; textSize = 48f; setTextColor(Color.rgb(96,165,250)); gravity = Gravity.CENTER })
        emptyState.addView(TextView(this).apply { text = "Nenhum PDF aberto"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg()); gravity = Gravity.CENTER; setPadding(0, 8, 0, 4) })
        emptyState.addView(TextView(this).apply { text = "Toque em Abrir PDF para começar a ler."; textSize = 13f; setTextColor(muted()); gravity = Gravity.CENTER })
        root.addView(emptyState, LinearLayout.LayoutParams(-1, 0, 1f))
        val bottom = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(0, 12, 0, 0) }
        bottom.addView(action("⌂  Início", "Início") { buildHome() }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(action("★  Favoritos", "Páginas favoritas") { showBookmarks() }, LinearLayout.LayoutParams(0, 48, 1f))
        bottom.addView(action("↗  Compartilhar", "Compartilhar PDF") { sharePdf() }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(bottom)
        setContentView(root)
    }

    private fun openPdf(uri: Uri, reset: Boolean = true) {
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        try {
            renderer?.close(); descriptor?.close()
            descriptor = contentResolver.openFileDescriptor(uri, "r") ?: throw Exception("Não foi possível abrir o arquivo")
            renderer = PdfRenderer(descriptor!!)
            currentUri = uri
            if (reset) page = 0
            page = page.coerceIn(0, (renderer!!.pageCount - 1).coerceAtLeast(0))
            prefs.edit().putString("last_uri", uri.toString()).putInt("last_page", page).apply()
            buildReader()
            renderPage()
        } catch (e: Exception) { toast("Erro ao abrir PDF: ${e.message}") }
    }

    private fun buildReader() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 12, 14, 10); setBackgroundColor(bg()) }
        val bar = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        bar.addView(action("‹", "Voltar à biblioteca") { buildHome() })
        val name = currentUri?.lastPathSegment?.substringAfterLast('/') ?: "Documento PDF"
        bar.addView(TextView(this).apply { text = name; textSize = 15f; typeface = Typeface.DEFAULT_BOLD; setTextColor(fg()); maxLines = 1; ellipsize = android.text.TextUtils.TruncateAt.MIDDLE }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(action("⌕", "Pesquisar no PDF") { searchDialog() })
        bar.addView(action("☆", "Favoritar página") { bookmarkPage() })
        root.addView(bar)
        pageImage = ImageView(this).apply { adjustViewBounds = true; scaleType = ImageView.ScaleType.MATRIX; setBackgroundColor(if (dark) Color.rgb(37,43,54) else Color.rgb(225,229,235)) }
        var zoom = 1f
        val imageMatrix = Matrix()
        val detector = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                zoom = (zoom * detector.scaleFactor).coerceIn(1f, 4f)
                imageMatrix.setScale(zoom, zoom)
                pageImage.imageMatrix = imageMatrix
                return true
            }
        })
        pageImage.setOnTouchListener { _, event -> detector.onTouchEvent(event); true }
        val scroll = ScrollView(this).apply { fillViewport = true; addView(pageImage) }
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f).apply { topMargin = 10; bottomMargin = 10 })
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(action("−", "Página anterior") { go(-1) }, LinearLayout.LayoutParams(0, 48, 1f))
        pageLabel = TextView(this).apply { text = "Página 1"; textSize = 14f; setTextColor(fg()); gravity = Gravity.CENTER }
        controls.addView(pageLabel, LinearLayout.LayoutParams(0, 48, 2f))
        controls.addView(action("＋", "Próxima página") { go(1) }, LinearLayout.LayoutParams(0, 48, 1f))
        root.addView(controls)
        val tools = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        tools.addView(action("☾ Tema", "Alternar tema") { toggleTheme() }, LinearLayout.LayoutParams(0, 44, 1f))
        tools.addView(action("↗ Enviar", "Compartilhar") { sharePdf() }, LinearLayout.LayoutParams(0, 44, 1f))
        root.addView(tools)
        setContentView(root)
    }

    private fun renderPage() {
        val r = renderer ?: return
        if (r.pageCount == 0) return
        val p = r.openPage(page)
        val width = (resources.displayMetrics.widthPixels * 1.7f).toInt().coerceAtLeast(900)
        val height = (width.toFloat() * p.height / p.width).toInt()
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        bitmap.eraseColor(Color.WHITE)
        p.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        p.close()
        pageImage.setImageBitmap(bitmap)
        pageImage.imageMatrix = Matrix()
        pageLabel.text = "Página ${page + 1} de ${r.pageCount}"
        prefs.edit().putInt("last_page", page).apply()
    }

    private fun go(delta: Int) { val count = renderer?.pageCount ?: return; val next = (page + delta).coerceIn(0, count - 1); if (next != page) { page = next; renderPage() } }

    private fun searchDialog() {
        val input = EditText(this).apply { hint = "Digite uma palavra ou frase"; setSingleLine(true) }
        AlertDialog.Builder(this).setTitle("Pesquisar no documento").setView(input)
            .setNegativeButton("Cancelar", null).setPositiveButton("Pesquisar") { _, _ ->
                val term = input.text.toString().trim(); if (term.isNotEmpty()) searchText(term)
            }.show()
    }

    private fun searchText(term: String) {
        val uri = currentUri ?: return
        toast("Pesquisando no documento…")
        thread {
            var found = -1
            try {
                val temp = File(cacheDir, "search.pdf")
                contentResolver.openInputStream(uri)!!.use { input -> FileOutputStream(temp).use { output -> input.copyTo(output) } }
                PDDocument.load(temp).use { doc ->
                    val stripper = PDFTextStripper()
                    for (i in 1..doc.numberOfPages) {
                        stripper.startPage = i; stripper.endPage = i
                        if (stripper.getText(doc).contains(term, true)) { found = i - 1; break }
                    }
                }
                temp.delete()
            } catch (_: Exception) { }
            runOnUiThread {
                if (found >= 0) { page = found; renderPage(); toast("Encontrado na página ${found + 1}") }
                else toast("Texto não encontrado. PDFs digitalizados podem precisar de OCR.")
            }
        }
    }

    private fun bookmarkPage() {
        val uri = currentUri ?: return
        val key = "bookmarks_${uri}"
        val set = prefs.getStringSet(key, emptySet())?.toMutableSet() ?: mutableSetOf()
        val value = (page + 1).toString()
        if (set.add(value)) toast("Página ${page + 1} adicionada aos favoritos") else { set.remove(value); toast("Favorito removido") }
        prefs.edit().putStringSet(key, set).apply()
    }

    private fun showBookmarks() {
        val uri = currentUri ?: prefs.getString("last_uri", null)?.let(Uri::parse)
        if (uri == null) { toast("Abra um PDF primeiro"); return }
        val pages = prefs.getStringSet("bookmarks_${uri}", emptySet())?.toList()?.sortedBy { it.toIntOrNull() ?: 0 } ?: emptyList()
        if (pages.isEmpty()) { toast("Nenhuma página favorita neste documento"); return }
        AlertDialog.Builder(this).setTitle("Páginas favoritas")
            .setItems(pages.map { "Página $it" }.toTypedArray()) { _, which ->
                if (currentUri != uri) openPdf(uri)
                page = (pages[which].toInt() - 1).coerceAtLeast(0)
                if (renderer != null) { buildReader(); renderPage() }
            }.setNegativeButton("Fechar", null).show()
    }

    private fun sharePdf() {
        val uri = currentUri ?: return toast("Abra um PDF primeiro")
        val intent = Intent(Intent.ACTION_SEND).apply { type = "application/pdf"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(intent, "Compartilhar PDF"))
    }

    private fun toggleTheme() { dark = !dark; prefs.edit().putBoolean("dark", dark).apply(); if (renderer != null) { buildReader(); renderPage() } else buildHome() }
    private fun action(label: String, description: String, click: () -> Unit) = Button(this).apply { text = label; contentDescription = description; isAllCaps = false; textSize = 13f; setTextColor(fg()); backgroundTintList = android.content.res.ColorStateList.valueOf(if (dark) Color.rgb(36,48,67) else Color.rgb(232,238,247)); setOnClickListener { click() } }
    private fun bg() = if (dark) Color.rgb(16,24,39) else Color.rgb(247,249,252)
    private fun fg() = if (dark) Color.WHITE else Color.rgb(24,35,52)
    private fun muted() = if (dark) Color.rgb(164,178,198) else Color.rgb(102,116,137)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    override fun onDestroy() { renderer?.close(); descriptor?.close(); super.onDestroy() }
}
